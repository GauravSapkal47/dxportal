// export const baseURL: string = 'http://localhost:8080/DxProject'
export const baseURL: string = 'https://wsqa.timesgroup.com/dxProject'

/*Url For The Data Like PO Details And All*/ 
export const blobURL= './assets/DX-Project/poDetails/';