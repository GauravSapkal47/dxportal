export  interface  User {
    PAN: string;
    Email: string;
}